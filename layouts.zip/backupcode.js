<div class="container-fluid">
<div class="row">
  <div class="col-md-3">
      left
  </div>

  <div class="col-md-6">
      center
  </div>

  <div class="col-md-3">
      right
  </div>

</div>
</div>
