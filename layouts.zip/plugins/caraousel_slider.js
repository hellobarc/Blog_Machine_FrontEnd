import Vue from 'vue';
import VueHorizontalList from "vue-horizontal-list";

Vue.use(VueHorizontalList)
