/* eslint-disable import/first */
import Vue from 'vue';
import VueScrollIndicator from 'vue-scroll-indicator';
Vue.use(VueScrollIndicator);





