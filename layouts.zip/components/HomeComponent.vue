<template lang="">
    <div>
         Home Component
    </div>
</template>
<script>
export default {

}
</script>
<style lang="">

</style>
