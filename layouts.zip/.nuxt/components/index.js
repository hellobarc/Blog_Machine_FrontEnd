export const FeaturedComponent = () => import('../..\\components\\FeaturedComponent.vue' /* webpackChunkName: "components/featured-component" */).then(c => wrapFunctional(c.default || c))
export const HeroComponent = () => import('../..\\components\\HeroComponent.vue' /* webpackChunkName: "components/hero-component" */).then(c => wrapFunctional(c.default || c))
export const HomeComponent = () => import('../..\\components\\HomeComponent.vue' /* webpackChunkName: "components/home-component" */).then(c => wrapFunctional(c.default || c))
export const LatestpostComponent = () => import('../..\\components\\LatestpostComponent.vue' /* webpackChunkName: "components/latestpost-component" */).then(c => wrapFunctional(c.default || c))
export const CommonFooterComponent = () => import('../..\\components\\common\\FooterComponent.vue' /* webpackChunkName: "components/common-footer-component" */).then(c => wrapFunctional(c.default || c))
export const CommonHeaderComponent = () => import('../..\\components\\common\\HeaderComponent.vue' /* webpackChunkName: "components/common-header-component" */).then(c => wrapFunctional(c.default || c))
export const CommonNavigationComponent = () => import('../..\\components\\common\\NavigationComponent.vue' /* webpackChunkName: "components/common-navigation-component" */).then(c => wrapFunctional(c.default || c))
export const CommonSearchComponent = () => import('../..\\components\\common\\SearchComponent.vue' /* webpackChunkName: "components/common-search-component" */).then(c => wrapFunctional(c.default || c))
export const PartsCarauselComponent = () => import('../..\\components\\parts\\CarauselComponent.vue' /* webpackChunkName: "components/parts-carausel-component" */).then(c => wrapFunctional(c.default || c))
export const PartsCardPost = () => import('../..\\components\\parts\\CardPost.vue' /* webpackChunkName: "components/parts-card-post" */).then(c => wrapFunctional(c.default || c))
export const PartsCategoryWidget = () => import('../..\\components\\parts\\CategoryWidget.vue' /* webpackChunkName: "components/parts-category-widget" */).then(c => wrapFunctional(c.default || c))
export const PartsReadmoreButton = () => import('../..\\components\\parts\\ReadmoreButton.vue' /* webpackChunkName: "components/parts-readmore-button" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
