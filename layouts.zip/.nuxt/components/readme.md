# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<FeaturedComponent>` | `<featured-component>` (components/FeaturedComponent.vue)
- `<HeroComponent>` | `<hero-component>` (components/HeroComponent.vue)
- `<HomeComponent>` | `<home-component>` (components/HomeComponent.vue)
- `<LatestpostComponent>` | `<latestpost-component>` (components/LatestpostComponent.vue)
- `<CommonFooterComponent>` | `<common-footer-component>` (components/common/FooterComponent.vue)
- `<CommonHeaderComponent>` | `<common-header-component>` (components/common/HeaderComponent.vue)
- `<CommonNavigationComponent>` | `<common-navigation-component>` (components/common/NavigationComponent.vue)
- `<CommonSearchComponent>` | `<common-search-component>` (components/common/SearchComponent.vue)
- `<PartsCarauselComponent>` | `<parts-carausel-component>` (components/parts/CarauselComponent.vue)
- `<PartsCardPost>` | `<parts-card-post>` (components/parts/CardPost.vue)
- `<PartsCategoryWidget>` | `<parts-category-widget>` (components/parts/CategoryWidget.vue)
- `<PartsReadmoreButton>` | `<parts-readmore-button>` (components/parts/ReadmoreButton.vue)
